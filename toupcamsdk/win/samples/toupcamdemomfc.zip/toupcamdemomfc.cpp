#include "stdafx.h"
#include "toupcamdemomfc.h"
#include "toupcamdemomfcDlg.h"

BEGIN_MESSAGE_MAP(CtoupcamdemomfcApp, CWinApp)
END_MESSAGE_MAP()

CtoupcamdemomfcApp::CtoupcamdemomfcApp()
{
}

CtoupcamdemomfcApp theApp;

BOOL CtoupcamdemomfcApp::InitInstance()
{
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();

	SetRegistryKey(_T("toupcamdemomfc"));

	CtoupcamdemomfcDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();

	return FALSE;
}

